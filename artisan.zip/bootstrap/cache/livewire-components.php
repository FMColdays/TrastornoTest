<?php return array (
  'select-component' => 'App\\Http\\Livewire\\SelectComponent',
);