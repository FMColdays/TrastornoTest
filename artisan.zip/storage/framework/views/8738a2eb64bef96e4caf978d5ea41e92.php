

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo', 'Login'); ?>

<?php $__env->startSection('cuerpo'); ?>
    <main class="main">
        <?php if(session('mensaje')): ?>
            <div class="error-login">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <section class="contenedor-login">
            <section class="contenedor-img">

                <h2 class="nombretec-titulo">Test TecNM / ITTG</h2>

                <picture>
                    <source sizes="1920w" srcset=" <?php echo e(asset('img/avif/nombretec.avif')); ?> 1920w" type="image/avif">
                    <source sizes="1920w" srcset="<?php echo e(asset('img/webp/nombretec.webp')); ?> 1920w" type="image/webp">
                    <source sizes="1920w" srcset="<?php echo e(asset('img/jpg/nombretec.png')); ?> 1920w" type="image/jpeg">
                    <img loading="lazy" decoding="async" src="<?php echo e(asset('img/jpg/nombretec.png')); ?>" lazyalt="imagen"
                        width="500" height="300">
                </picture>
            </section>

            <section class="contenedor-contenido">
                <form class="form-login" action="<?php echo e(route('validar')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <p class="form-login__titulo">Iniciar Sesión</>
                    <div class="form-login-input">
                        <span class="form-login__icono">
                            <i class="fa fa-user-circle"></i>
                        </span>
                        <input class="form-login__correo" type="email" name="correo" id="usuario"
                            placeholder="Coreo Institucional">
                    </div>
                    <div class="form-login-input">
                        <span class="form-login__icono">
                            <i class="fa fa-lock"></i>
                        </span>
                        <input class="form-login__contraseña" name="contraseña" id="contraseña" type="password"
                            placeholder="Contraseña">
                        <span class="togglePassword" id="togglePassword"><i id="ojo" class="fa-solid fa-eye"></i></span>
                    </div>

                    <input class="btn-sesion" type="submit" value="Iniciar sesión">
                </form>
                <a class="a-registrarse" href="<?php echo e(route('registro')); ?>">Registrarse</a>
            </section>

        </section>
    </main>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/img.js')); ?>"></script>
    <script src="<?php echo e(asset('js/login.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\AppTestTrastornos\resources\views/auth/login.blade.php ENDPATH**/ ?>