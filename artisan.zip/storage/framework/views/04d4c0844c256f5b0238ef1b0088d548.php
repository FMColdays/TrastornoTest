

<?php $__env->startSection('contenido'); ?>
    <div class="contenedor-tabla-usuarios">
        <div class="card-cuerpo">
            <table id="usuarios" class="table table-striped">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>nombreTest</th>
                        <th>descripcion</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($test->id); ?></td>
                            <td><?php echo e($test->nombreTest); ?></td>
                            <td><?php echo e($test->descripcion); ?></td>

                            <td>
                                <a href="#">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </a>


                                <form class="eliminar-alert" action="" method="post" style="display: inline-block;">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <a href="#" type="submit">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                   Z
                                </form>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\AppTestTrastornos\resources\views/admin/test.blade.php ENDPATH**/ ?>