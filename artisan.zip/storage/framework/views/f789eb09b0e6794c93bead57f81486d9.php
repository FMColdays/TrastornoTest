<?php $__env->startSection('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('css/registro.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo', 'Registrarse'); ?>

<?php $__env->startSection('cuerpo'); ?>
    <header class="header-registro"></header>

    <div class="contenedor-registro">
        <div class="contenedor contenido-preguntas">
            <form id="formulario" action="<?php echo e(route('registrarse')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="pregunta">
                    <h1 class="titulo-registro">Registrarse</h1>
                </div>

                <div class="pregunta">
                    <label class="label-registro" for="numeroControl">Numero de control</label>
                    <input class="input-registro" id="numeroControl" type="text" name="numeroControl"
                        placeholder="Numero de control" value=<?php echo e(old('numeroControl')); ?>>

                    <?php $__errorArgs = ['numeroControl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-registro">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="pregunta">
                    <label class="label-registro" for="correo">Correo institucional</label>
                    <input class="input-registro" id="correo" type="email" name="correo"
                        placeholder="Correo institucional" value=<?php echo e(old('correo')); ?>>

                    <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-registro">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="pregunta">
                    <label class="label-registro" for="contraseña">Contraseña</label>
                    <input class="input-registro" id="contraseña" type="password" name="contraseña"
                        placeholder="Contraseña">

                    <ul class="requisitosPassword">
                        <li>Minimo 8 caracteres</li>
                        <li>Al menos una mayuscula</li>
                        <li>Al menos un numero</li>
                        <li>Sin caracteres especiales</li>
                    </ul>

                    <?php $__errorArgs = ['contraseña'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-registro">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="pregunta">
                    <label class="label-registro" for="contraseña2">Confirmar contraseña</label>
                    <input class="input-registro" id="contraseña2" type="password" name="contraseña2"
                        placeholder="Repita su contraseña">

                    <?php $__errorArgs = ['contraseña2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-registro">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <p class="errorE coincidencia">Las contraseñas no coinciden</p>
                </div>

                <div class="pregunta">
                    <label class="label-registro" for="instituto">Instituto</label>
                    <select id="buscador" class="section-registro" name="instituto_id">
                        <?php $__currentLoopData = $institutos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instituto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($instituto->id); ?>" <?php echo e(old('instituto_id') == $instituto->id ? 'selected' : ''); ?>>
                                <?php echo e($instituto->nombre_instituto); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="pregunta">
                    <label class="label-registro" for="carrera">Carrera</label>
                    <select id="carrera" class="section-registro" name="carrera_id" required>
                        <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option class="opcionesI" id="<?php echo e($carrera->instituto_id); ?>" value="<?php echo e($carrera->id); ?>"
                                <?php echo e(old('carrera_id') == $carrera->id ? 'selected' : ''); ?>>
                                <?php echo e($carrera->nombre_carrera); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                


                <div class="pregunta">
                    <label class="label-registro" for="semestre">Semestre</label>
                    <select class="section-registro" name="semestre_id">
                        <?php $__currentLoopData = $semestres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semestre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($semestre->id); ?>" <?php echo e(old('semestre_id') == $semestre->id ? 'selected' : ''); ?>>
                                <?php echo e($semestre->numero_semestre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                
                <div class="pregunta">
                    <label class="label-registro" for="edad">Edad</label>
                    <input class="input-registro" id="edad" type="text" name="edad" placeholder="Edad"
                        value=<?php echo e(old('edad')); ?>>
                    <?php $__errorArgs = ['edad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-registro">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="pregunta">
                    <label class="label-registro" for="sexo">Sexo</label>
                    <select id="sexo" class="section-registro" name="sexo">
                        <option value="0" <?php echo e(old('sexo') == 0 ? 'selected' : ''); ?>>Hombre</option>
                        <option value="1" <?php echo e(old('sexo') == 1 ? 'selected' : ''); ?>>Mujer</option>
                    </select>
                </div>
                
                <input class="btnregistrar" id="btnregistrar" type="submit" value="Registrar">
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="<?php echo e(asset('js/img.js')); ?>"></script>
    <script src="<?php echo e(asset('js/registro.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\AppTestTrastornos\resources\views/auth/registro.blade.php ENDPATH**/ ?>