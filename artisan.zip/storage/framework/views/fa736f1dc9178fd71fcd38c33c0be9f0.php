<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Certificado ACOM</title>
</head>

<body>
    <div>

        <div id="contenedorQR"></div>

        <div id="svg-container">
            <?php echo e(QrCode::size(500)->generate('http://127.0.0.1:8000/estudiante/' . auth()->user()->numeroControl . '/edit')); ?>

        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/canvg/1.5/canvg.min.js"></script>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>
        <script>
            var svg = document.getElementById('svg-container').innerHTML;
            console.log(svg);
            if (svg) svg = svg.replace(/\r?\n|\r/g, '').trim();
                
            let canvas = document.createElement('canvas');
            var context = canvas.getContext('2d');


            context.clearRect(0, 0, canvas.width, canvas.height);
            canvg(canvas,svg);

            var imgData = canvas.toDataURL('image/png');

            var doc = new jsPDF('p', 'pt', 'a4');
            doc.addImage(imgData, 'PNG', 180, 200, 250, 250);
            doc.save('test.pdf');

        </script>

</body>

</html>
<?php /**PATH C:\laragon\www\AppTestTrastornos\resources\views/pdf/descargar.blade.php ENDPATH**/ ?>