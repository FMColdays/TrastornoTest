
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="<?php echo e(asset('css/test.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo', $nombre); ?>

<?php $__env->startSection('cuerpo'); ?>

    <div>
        <header class="header-preguntas" style="background-color:gray"></header>

        <div class="contenedor-preguntas">
            <div class="contenedor contenido-preguntas">
                <div class="test-div-realizado">
                    <?php echo csrf_field(); ?>

                    <div class="pregunta">
                        <h1 class="titulo-pregunta">Test de <?php echo e($nombre); ?></h1>
                    </div>

                    <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unapregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="pregunta test-validar">

                            <label value="<?php echo e($unapregunta->id); ?>"><?php echo e($unapregunta->pregunta); ?></label>

                            <?php $__currentLoopData = $unapregunta->opciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unaopcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $opcionSeleccionada = $opciones->firstWhere('opcion_id', $unaopcion->id);
                                    $checked = $opcionSeleccionada ? 'checked' : '';
                                    $disabled = $opcionSeleccionada ? '' : 'disabled';
                                ?>
                                <div>
                                    <label class="radio-contenedor">

                                        <input id="<?php echo e($unaopcion->id); ?>" type="radio" name="<?php echo e($unapregunta->id); ?>"
                                            value="<?php echo e($unaopcion->id); ?>" <?php echo e($checked); ?> <?php echo e($disabled); ?>>
                                        <span class="radio-select">
                                            <i class="fa-solid fa-circle"></i>
                                        </span>
                                    </label>
                                    <label for="<?php echo e($unaopcion->id); ?>"><?php echo e($unaopcion->opcion); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </div>

            </div>
        </div>
    </div>

    <footer class="footer">
        <p><span>Test</span> TecNM</p>
    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\AppTestTrastornos\resources\views/testRealizado.blade.php ENDPATH**/ ?>