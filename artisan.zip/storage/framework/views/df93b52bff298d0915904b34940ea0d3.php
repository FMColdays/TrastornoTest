<?php if(count($estudiantes) == 0): ?>
  No se encontraon resultados
<?php endif; ?>

<?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="enlace" href="<?php echo e(route('estudiante.edit', $estudiante)); ?>">
        <div class="card-estudiantes"
            <?php if($estudiante->confirmacion == 0): ?> style="background-color: #dfb0b0" 
        <?php else: ?> style="background-color:#b0dfbd" <?php endif; ?>>

            <div>
                <h4>Numero de control</h4>
                <p class="numeroControl"><?php echo e($estudiante->numeroControl); ?></p>
            </div>

            <div>
                <h4>Correo</h4>
                <p class="correo"><?php echo e($estudiante->correo); ?></p>
            </div>

            <div>
                <h4>Instituto</h4>
                <p class="instituto"><?php echo e($estudiante->instituto->nombre_instituto); ?></p>
            </div>

            <div>
                <h4>Carrera</h4>
                <p class="carrera"><?php echo e($estudiante->carrera->nombre_carrera); ?></p>
            </div>

            <div>
                <h4>Semestre</h4>
                <p class="semestre"><?php echo e($estudiante->semestre->numero_semestre); ?></p>
            </div>
            <?php if(!is_null($estudiante->id_certificado)): ?>
                <div>
                    <h4>Numero certificado</h4>
                    <p><?php echo e($estudiante->id_certificado); ?></p>
                </div>
            <?php endif; ?>

        </div>
    </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div style="display: none">
    <?php echo e($estudiantes->links()); ?>

</div>
<?php /**PATH C:\laragon\www\AppTestTrastornos\resources\views/admin/load.blade.php ENDPATH**/ ?>