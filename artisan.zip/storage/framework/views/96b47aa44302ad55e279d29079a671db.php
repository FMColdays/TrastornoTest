

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="<?php echo e(asset('css/test.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo', $nombre); ?>

<?php $__env->startSection('cuerpo'); ?>

<?php $__env->startSection('color'); ?>
    style="background-color: <?php echo e($color); ?> "
<?php $__env->stopSection(); ?>

<div>
    <header class="header-preguntas" style="background-color:<?php echo e($color); ?>"></header>

    <div class="contenedor-preguntas">

        <div class="contenedor contenido-preguntas">
            <form id="test-form" action="<?php echo e(route('guardarTest')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="test_id" value="<?php echo e(encrypt($test->id)); ?>">
                <input type="hidden" name="nombre" value="<?php echo e(encrypt($nombre)); ?>">

                <div class="pregunta">
                    <h1 class="titulo-pregunta">Test de <?php echo e($nombre); ?></h1>
                    <p class="error-login">*Debe rellenar todos los campos</p>
                </div>

                <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unapregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="pregunta test-validar">
                        <label value="<?php echo e($unapregunta->id); ?>"><?php echo e($unapregunta->pregunta); ?></label>

                        <?php $__currentLoopData = $unapregunta->opciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unaopcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <label class="radio-contenedor">
                                    <input id="<?php echo e($unaopcion->id); ?>" type="radio"
                                        name="<?php echo e($unapregunta->id); ?>"value="<?php echo e($unaopcion->id); ?>">
                                    <span class="radio-select">
                                        <i class="fa-solid fa-circle"></i>
                                    </span>
                                </label>
                                <label for="<?php echo e($unaopcion->id); ?>"><?php echo e($unaopcion->opcion); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <input type="submit" value="Enviar">
            </form>
        </div>
    </div>
</div>

<footer class="footer">
    <p><span>Test</span> TecNM</p>
</footer>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/test.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\AppTestTrastornos\resources\views/test.blade.php ENDPATH**/ ?>