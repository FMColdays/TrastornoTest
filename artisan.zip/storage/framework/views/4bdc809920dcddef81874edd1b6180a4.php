<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/3923/3923306.png" />
    <link
        href="https://fonts.googleapis.com/css2?family=Lato:wght@400;900&family=Roboto:wght@100;400;700;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/normalize.css')); ?>" />
    <?php echo $__env->yieldContent('css'); ?>
    <title><?php echo $__env->yieldContent('titulo'); ?></title>
</head>

<body <?php echo $__env->yieldContent('color'); ?>>

    <?php echo $__env->yieldContent('cuerpo'); ?>
    <?php echo $__env->yieldContent('js'); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\AppTestTrastornos\resources\views/plantillas/plantilla.blade.php ENDPATH**/ ?>