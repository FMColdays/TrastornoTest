

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('css/inicioAdmin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo', 'Inicio'); ?>

<?php $__env->startSection('id'); ?>
    id ="body"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo'); ?>
    <header>
        <div class="icon__menu">
            <i class="fas fa-bars" id="btn_open"></i>
        </div>
        <div class="logo__menu">
            <img src="<?php echo e(asset('img/jpg/nombretec.png')); ?>" alt="nombretec">
        </div>
    </header>

    <div class="menu__side" id="menu_side">


        <div class="options__menu">

            <a href="<?php echo e(url('/')); ?>" class="<?php echo e(Request::path() == '@me' ? 'selected' : ''); ?>">
                <div class="option">
                    <i class="fas fa-home"></i>
                    <h4>Inicio</h4>
                </div>
            </a>

            <a href="<?php echo e(route('estudiante.index')); ?>" class="<?php echo e(Request::path() == 'estudiante' ? 'selected' : ''); ?>">
                <div class="option">
                    <i class="fa-solid fa-graduation-cap"></i>
                    <h4>Estudiantes</h4>
                </div>
            </a>

            <a href="<?php echo e(route('test.index')); ?>" class="<?php echo e(Request::path() == 'test' ? 'selected' : ''); ?>">
                <div class="option">
                    <i class="fa-solid fa-book"></i>
                    <h4>Tests</h4>
                </div>
            </a>

            <a href="<?php echo e(route('logout')); ?>">
                <div class="option">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    <h4>Cerrar sesion</h4>
                </div>
            </a>

        </div>


    </div>

    <main>

     
            <?php echo $__env->yieldContent('contenido'); ?>
       

    </main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.4.1/js/responsive.bootstrap5.min.js"></script>

    <script src="<?php echo e(asset('js/inicioAdmin.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\AppTestTrastornos\resources\views/admin/index.blade.php ENDPATH**/ ?>