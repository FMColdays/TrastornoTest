

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('css/resultado.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo', 'resultado'); ?>

<?php $__env->startSection('cuerpo'); ?>


    <div>

        <header class="contenedor header-resulado">

        </header>

        <main class="contenedor main-resultado">
            <div class="text-center">
                <h2 class="fw-bold mb-2 text-uppercase">Resultados del Test</h2>
            </div>
            <div class="d-grid gap-2">
                <h5 style="text-align: center">Diagnostico de </h5>
                <div style="display: flex; flex-direction: column; justify-content:space-around; align-items:center"
                    action="{% url 'inicio' %}" method="post">

                    <pre>Fecha: <?php echo e(date('d-m-Y')); ?> </pre>
                    <pre>Folio: <?php echo e($res); ?></pre>
                    <input type="submit" value="Finalizar" class="botonIn pregunta">
                </div>
            </div>
        </main>

    </div>

    <footer class="footer">
        <p><span>Test</span> TecNM</p>
    </footer>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\AppTestTrastornos\resources\views/test/resultado.blade.php ENDPATH**/ ?>