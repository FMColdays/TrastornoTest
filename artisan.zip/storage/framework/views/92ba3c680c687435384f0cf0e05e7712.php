<div class="pregunta">
    <label class="label-registro" for="instituto">Instituto</label>
    <select id="buscador" class="section-registro" name="instituto" wire:model="instituto">
        <?php $__currentLoopData = $institutos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instituto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($instituto->id); ?>><?php echo e($instituto->nombre_instituto); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="pregunta">
    <label class="label-registro" for="carrera">Carrera</label>
    <select id="carrera" class="section-registro" name="carrera" wire:model="carrera">
        <?php if($carreras->count() == 0): ?>
            <option value="none">Debe seleccionar un instituto</option>
        <?php endif; ?>
        <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($carrera->id); ?>><?php echo e($carrera->nombre_instituto); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>
</div>
<?php /**PATH C:\laragon\www\AppTestTrastornos\resources\views/livewire/select-component.blade.php ENDPATH**/ ?>