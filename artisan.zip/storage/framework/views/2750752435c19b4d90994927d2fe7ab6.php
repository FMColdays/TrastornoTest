

<?php $__env->startSection('contenido'); ?>
    <div>
        <form action="<?php echo e(route('estudiante.update', $estudiante)); ?>" method="post">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <label for="">no</label>
            <input type="radio" name="confirmacion" value="0" <?php if($estudiante->confirmacion == '0'): ?> checked <?php endif; ?>>
            <label for="">si</label>
            <input type="radio" name="confirmacion" value="1" <?php if($estudiante->confirmacion == '1'): ?> checked <?php endif; ?>>
            <input type="submit">
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\AppTestTrastornos\resources\views/admin/estudiante.blade.php ENDPATH**/ ?>