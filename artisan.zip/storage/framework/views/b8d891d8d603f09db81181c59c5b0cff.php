

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('css/inicio.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo', 'Inicio'); ?>

<?php $__env->startSection('cuerpo'); ?>

    <header class="header">

        <div class="contenedor imagen-header">
            <picture>
                <source sizes="1920w" srcset=" <?php echo e(asset('img/avif/logotec.avif')); ?> 1920w" type="image/avif">
                <source sizes="1920w" srcset="<?php echo e(asset('img/webp/logotec.webp')); ?> 1920w" type="image/webp">
                <source sizes="1920w" srcset="<?php echo e(asset('img/jpg/logotec.png')); ?> 1920w" type="image/jpeg">
                <img loading="lazy" decoding="async" src="<?php echo e(asset('img/jpg/logotec.png')); ?>" lazyalt="imagen"
                    width="500" height="300">
            </picture>
        </div>

        <div class="contenedor-ancle">
            <?php if(auth()->user()->testRealizado()->count() > 8): ?>
                <a href="javascript:generarPDF()"><i class="fa-solid fa-file-pdf fa-xl"></i></a>
                <div id="svg-container" style="display: none">
                    <?php echo e(QrCode::size(500)->generate('http://127.0.0.1:8000/estudiante/' . auth()->user()->numeroControl . '/edit')); ?>

                </div>
            <?php endif; ?>

            <a href="<?php echo e(route('logout')); ?>">Cerrar sesion</a>
        </div>
    </header>

    <main class="main-test">
        <div class="contenedor">
            <p class="contenedor__iniciaTest">Inicia un test</p>
            <div class="contenedor-test">
                <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $testRealizado = $testRealizados->where('test_id', $test->id)->first();
                    ?>

                    <?php if(!$testRealizado): ?>
                        <div>
                            <a href="<?php echo e(route('test.show', $test)); ?>">
                                <div class="test">
                                    <img src="https://ssl.gstatic.com/docs/templates/thumbnails/1R2sTjfMFHee6VYVhuz8Tpi78mROlLWY4XgaKkJKMuis_400.png"
                                        alt="imagen-test">
                                </div>
                            </a>
                            <p class="nombre-test">Test <?php echo e($test->nombreTest); ?></p>
                        </div>
                    <?php else: ?>
                        <div>
                            <div class="test-null">
                                <i class="fa-solid fa-circle-check" style="color: #066a17;"></i>
                                <img class="imagen-realizado"
                                    src="https://ssl.gstatic.com/docs/templates/thumbnails/1R2sTjfMFHee6VYVhuz8Tpi78mROlLWY4XgaKkJKMuis_400.png"
                                    alt="imagen-test">
                            </div>
                            <p class="nombre-test">Test <?php echo e($test->nombreTest); ?></p>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </main>

    <section class="realizados">
        <div class="contenedor ">

            <p class="contenedor__realizadoTest">
                <?php echo e(count($testRealizados) == 0 ? 'No haz realizado ningun test' : 'Test Realizados'); ?></p>

            <div class="contenedor-test-realizados ">
                <?php $__currentLoopData = $testRealizados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testRealizado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('testRealizado.show', $testRealizado)); ?>">

                        <div class="test-realizados">
                            <img src="https://ssl.gstatic.com/docs/templates/thumbnails/1R2sTjfMFHee6VYVhuz8Tpi78mROlLWY4XgaKkJKMuis_400.png"
                                alt="imagen-test">
                            <div class="nombre-test">
                                <?php echo e($testRealizado->test->nombreTest); ?>

                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </section>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/canvg/1.5/canvg.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>
    <script src="<?php echo e(asset('js/generarPDF.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\AppTestTrastornos\resources\views/inicio.blade.php ENDPATH**/ ?>